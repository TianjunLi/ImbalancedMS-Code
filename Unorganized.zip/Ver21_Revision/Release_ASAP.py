# %%
'''
nature based logarithm
'''
import numpy as np
import pandas as pd
import seaborn as sns
import statsmodels.api as sm
from matplotlib import patches
from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

def LoadData(ratio):
    Data = pd.read_csv('../Data/L_H-%s.csv'%(ratio))
    Ratio = Data['asap mean']
    AsapRatio = np.log2(Ratio.tolist())

    PPR = Data['PPR']
    Mono = Data['MonoPeak']

    return AsapRatio, Mono, 1/Ratio
# Cal the M and A for plotting
def CalMA(H_L, Mono):
    M = np.log2(1/H_L)
    A = np.log2(H_L*Mono**2)
    return M, A

def GeneNormal(SampleNum, ratiodata):
    x_value = np.linspace(np.min(ratiodata), np.max(ratiodata), SampleNum)
    Similar_Normal = np.random.normal(np.mean(ratiodata), 0.25, SampleNum)
    Skw_Normal = np.random.normal(np.mean(ratiodata), 1, SampleNum)
    return x_value, Similar_Normal, Skw_Normal

def GeneECDF(x_value, distdata):
    ecdf = sm.distributions.ECDF(distdata)
    y_value = ecdf(x_value)
    return y_value

def GetBoundaryIndex(data, lb, rb):
    tmplb = np.abs(data-lb).min()
    lbvalue = lb+tmplb
    lbloc = np.where(data==lbvalue)[0][0]

    tmprb = np.abs(data-rb).min()
    rbvalue = rb-tmprb
    rbloc = np.where(data==rbvalue)[0][0]

    return lbloc, rbloc


if __name__ == '__main__':
    rate = '1_1'
    AsapRatio, Mono, H_L = LoadData(rate)

    R_mean = np.mean(AsapRatio)
    R_std = np.std(AsapRatio)

    # Prepare MA plot
    M, A = CalMA(H_L.to_numpy(), Mono)

    # Prepare distribution
    X, Similar, Skw = GeneNormal(10000, AsapRatio)

    Asap_cdf = GeneECDF(X, AsapRatio)
    Simi_cdf = GeneECDF(X, Similar)
    Skw_cdf = GeneECDF(X, Skw)

    # Prepare cdf related
    LeftBoundary = R_mean - 3*R_std
    RightBoundary = R_mean + 3*R_std

    LeftBoundaryCDF = GeneECDF(LeftBoundary, AsapRatio)
    RightBoundaryCDF = GeneECDF(RightBoundary, AsapRatio)

    area = RightBoundaryCDF-LeftBoundaryCDF

    lb, rb = GetBoundaryIndex(X, LeftBoundary, RightBoundary)

    cdfx_left = X[:lb]
    cdfx_right = X[rb:]
    cdfx_mid = X[lb:rb]

    # Plot!
    from matplotlib.font_manager import FontProperties
    font = FontProperties()
    font.set_size(16)
    font.set_weight('bold')

    fig = plt.figure(figsize=(10, 5.5))

    ax1 = fig.add_subplot(221)
    ax1.set_title("MAplot, light/heavy peptide ratio = 1:1")
    ax1.plot(A, M, 'o', ms=7, mec='C0', mew='1', mfc='none')
    ax1.axhline(0, color='red', label='Ground Truth')
    ax1.text(16.8, 6.4, "a", fontproperties=font)
    ax1.legend()
    ax1.set_xlabel("A", fontsize=12)
    ax1.set_ylabel("M", fontsize=12)

    ax2 = fig.add_subplot(222)
    ax2.set_title("Histogram and corresponding KDE plot")
    ax2.hist(AsapRatio, bins=100, density=True, alpha=.4, label='Hist')
    ax2 = sns.distplot(AsapRatio, hist=False, bins=100, kde_kws={"color": "g", "lw": 2}, label='KDE')
    ax2.axvline(R_mean, linestyle='--', label=r'Mean$\approx$%s'%(round(R_mean, 2)), color='r')
    ax2.text(-6.8, 2.25, "b", fontproperties=font)
    ax2.set_xlabel("Value", fontsize=12)
    ax2.set_ylabel("Density frequency", fontsize=12)
    ax2.legend()

    ax3 = fig.add_subplot(223)
    # Add boundary for CDF
    ax3.set_title('Empirical cumulative distributions')
    ax3.axhline(0, 0.045, 0.955, color='r')
    ax3.axhline(1, 0.045, 0.955, color='r')
    # Plot similar dist
    # ax3.plot(X, Simi_cdf, lw=2, color='b', label="Normal\nN~(0.16, 0.25)")
    ax3.plot(X, Skw_cdf, lw=2, color='g', label="Normal\nN~(%s, 1)"%(round(R_mean,2)))
    ax3.plot(X, Asap_cdf, lw=2, color='orange', label=r'$\log_2$(ASAPRatio)')
    # 1 std boundary
    ax3.axvline(R_mean-R_std, 0.05, 0.95, color='C0', linestyle = '--', alpha=0.3)
    ax3.axvline(R_mean+R_std, 0.05, 0.95, color='C0', linestyle = '--', label=r'$\mu \pm \sigma$', alpha=0.3)
    # 2 std
    ax3.axvline(R_mean-2*R_std, 0.05, 0.95, color='C1', linestyle = '--', alpha=0.3)
    ax3.axvline(R_mean+2*R_std, 0.05, 0.95, color='C1', linestyle = '--', label=r'$\mu \pm 2\sigma$', alpha=0.3)
    # 3 std
    ax3.axvline(R_mean-3*R_std, 0.05, 0.95, color='C2', linestyle = '--', alpha=0.3)
    ax3.axvline(R_mean+3*R_std, 0.05, 0.95, color='C2', linestyle = '--', label=r'$\mu \pm 3\sigma$', alpha=0.3)
    # 4 std
    # ax3.axvline(R_mean-4*R_std, 0.05, 0.95, color='C3', linestyle = '--', alpha=0.3)
    # ax3.axvline(R_mean+4*R_std, 0.05, 0.95, color='C3', linestyle = '--', label=r'$\mu \pm 4\sigma$', alpha=0.3)
    ax3.text(-6.5, 1.08, "c", fontproperties=font)
    ax3.legend(fontsize=9)
    ax3.set_ylabel("Probability", fontsize=12)
    ax3.set_xlabel("Value", fontsize=12)

    ax4 = fig.add_subplot(224)
    ax4.set_title(r"ECDF for the $\log_2$(ratios) with 3$\sigma$ range")
    ax4.plot(X, Asap_cdf)
    ax4.fill_between(cdfx_mid, GeneECDF(cdfx_mid, AsapRatio), 0, facecolor='green', alpha=0.3)
    ax4.fill_between(cdfx_left, GeneECDF(cdfx_left, AsapRatio), 0, facecolor='red', alpha=0.7)
    ax4.fill_between(cdfx_right, GeneECDF(cdfx_right, AsapRatio), 1, facecolor='red', alpha=0.7)
    ax4.axvline(x=LeftBoundary, color='red', linestyle=':', lw=2)
    ax4.axvline(x=RightBoundary, color='red', linestyle=':', lw=2)
    ax4.text(0.1, 0.1, "%s%%"%(round(area,4)*100), fontsize=14)
    ax4.text(-6.6, 1.08, "d", fontproperties=font)
    ax4.set_ylim(-0.05, 1.05)
    ax4.set_ylabel("Probability", fontsize=12)
    ax4.set_xlabel("Value", fontsize=12)

    inset_ax1 = inset_axes(ax4, height="20%", width="20%", loc='center left', bbox_to_anchor=(0.1, -0.25, 1, 1), bbox_transform=ax4.transAxes)
    inset_ax1.plot(X, Asap_cdf)
    inset_ax1.axvline(x=LeftBoundary, color='red', linestyle=':', lw=2)
    inset_ax1.fill_between(cdfx_mid, GeneECDF(cdfx_mid, AsapRatio), 0, facecolor='green', alpha=0.3)
    inset_ax1.fill_between(cdfx_left, GeneECDF(cdfx_left, AsapRatio), 0, facecolor='red', alpha=0.7)
    inset_ax1.text(-2.45, 0.001, "%s%%"%(round(LeftBoundaryCDF,4)*100))
    inset_ax1.set_xlim(-2.5, -1.5)
    inset_ax1.set_ylim(0,0.02)
    inset_ax1.set_xticks([])
    inset_ax1.set_yticks([])

    inset_ax2 = inset_axes(ax4, height="20%", width="20%", loc='center right', bbox_to_anchor=(-0.05, 0.25, 1, 1), bbox_transform=ax4.transAxes)
    inset_ax2.plot(X, Asap_cdf)
    inset_ax2.axvline(x=RightBoundary, color='red', linestyle=':', lw=2)
    inset_ax2.fill_between(cdfx_mid, GeneECDF(cdfx_mid, AsapRatio), 0, facecolor='green', alpha=0.3)
    inset_ax2.fill_between(cdfx_right, GeneECDF(cdfx_right, AsapRatio), 1, facecolor='red', alpha=0.7)
    inset_ax2.text(2.4, 0.99, "%s%%"%(round((1-RightBoundaryCDF)*100,2)))
    inset_ax2.set_xlim(2, 3)
    inset_ax2.set_ylim(0.97,1)
    inset_ax2.set_xticks([])
    inset_ax2.set_yticks([])

    arrow1 = patches.FancyArrowPatch((-2.5, 0.1), (LeftBoundary, 0.01), arrowstyle = "<-", mutation_scale=20)
    ax4.add_patch(arrow1)

    arrow2 = patches.FancyArrowPatch((3, 0.9), (RightBoundary, 0.99), arrowstyle = "<-", mutation_scale=20)
    ax4.add_patch(arrow2)

    plt.tight_layout()
    plt.subplots_adjust(hspace=.38)

    plt.savefig("ASAP2.png", dpi=300, bbox_inches='tight')
    # plt.savefig("ASAP_All.eps", dpi=300, bbox_inches='tight')
    plt.savefig("Fig_2.pdf", dpi=300, bbox_inches='tight')






    plt.show()
#%%
