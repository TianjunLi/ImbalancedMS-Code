# %%
"""
==========================================
Applying different Classifier To Peptides, 2 based log
==========================================
"""

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
import math
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler
import warnings

from Func_LoadData import LoadSIDData, LoadNormalData
from Func_LoadModel import LoadModel

def PredictWithOrder(data, estimator, sorttype):
    '''
    sorttype: 'asc','desc'
    return: SortIndex, SortValue
    '''
    y_pred_prob = estimator.predict_proba(data)[:,1]
    iternum = y_pred_prob.shape[0]

    SortIndex = []
    SortValue = []
    if sorttype == 'asc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1])
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    elif sorttype == 'desc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1], reverse=True)
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    return SortIndex, np.asarray(SortValue)

def GetPredictRes(dataratio, datatype, estimator):
    '''
    datatype: 'sid', 'normal'
    '''
    datapath = "../Data/L_H-%s.csv"%(dataratio)
    if datatype == 'sid':
        AsapRatio, Data = LoadSIDData(datapath)
    elif datatype == 'normal':
        AsapRatio, Data = LoadNormalData(datapath)
    
    AsapRatio = np.log2(AsapRatio)

    Data = StandardScaler().fit_transform(Data)

    AscIndex, AscValues = PredictWithOrder(Data, estimator, 'asc')

    return AsapRatio[AscIndex], AscValues[AscValues>0.5].shape[0]

def CalLogCV(Data):
    tmpstd = np.std(Data)
    term = 2 ** (np.log(2)*(tmpstd**2)) - 1
    return np.sqrt(term)

def GetPickedRes(RatioList):
    num = RatioList.shape[0]
    CVList = []
    foldnum = np.int((1/100)*num)
    for i in range(90):
        StartIndex = i*foldnum
        RemainedRatio = RatioList[StartIndex:]
        CVList.append(CalLogCV(RemainedRatio))
    return CVList

def GetResWithRatio(ratio):
    S_SIP_clf = LoadModel('smote-sidxgb')
    S_SIP_Res, _ = GetPredictRes(ratio, 'sid', S_SIP_clf)
    S_SIPCV = GetPickedRes(S_SIP_Res)

    SIP_clf = LoadModel('sidxgb')
    SIP_Res, _ = GetPredictRes(ratio, 'sid', SIP_clf)
    SIPCV = GetPickedRes(SIP_Res)

    Base_clf = LoadModel('base')
    Base_Res, _ = GetPredictRes(ratio, 'normal', Base_clf)
    BaseCV = GetPickedRes(Base_Res)

    return S_SIPCV, SIPCV, BaseCV


# %%
if __name__ == "__main__":
    print (__doc__)

    ratio1 = "1_2"
    ratio2 = "1_1"
    ratio3 = "1-5_1"
    ratio4 = "2_1"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        S_CV1, CV1, BaseCV1 = GetResWithRatio(ratio1)
        S_CV2, CV2, BaseCV2 = GetResWithRatio(ratio2)
        S_CV3, CV3, BaseCV3 = GetResWithRatio(ratio3)
        S_CV4, CV4, BaseCV4 = GetResWithRatio(ratio4)

    fig = plt.figure(figsize=(10, 6))
    ax1 = fig.add_subplot(221)
    ax1.set_title("S. cerevisiae Yeast {}:{}".format(ratio1[0], ratio1[-1]))
    ax1.scatter(np.linspace(0, 90, 90), BaseCV1, marker='v', s=20, color='C0',label = 'SVM Baseline Method')
    ax1.scatter(np.linspace(0, 90, 90), CV1, marker='^', s=20, color='C1', label = 'XGBoost with SID Features')
    ax1.scatter(np.linspace(0, 90, 90), S_CV1, marker='p', s=20, color='C4',label = 'SMOTE XGBoost with SID Features')
    ax1.plot([0, 90],[0, 0], '--', linewidth=4, color='C3', label='Chance')
    ax1.plot([25, 25],[0.43, 0.65], linewidth=2, color='C2')
    ax1.plot([75, 75],[0.3, 0.65], linewidth=2, color='C2', label="Q1, Q3")
    ax1.legend(loc=(0.02, 0.08), fancybox=True, framealpha=0.5, fontsize=9)
    ax1.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax1.set_ylabel('Coefficient of Variation\nfor Log-transformed Data')

    ax2 = fig.add_subplot(222)
    ax2.set_title("S. cerevisiae Yeast {}:{}".format(ratio2[0], ratio2[-1]))
    ax2.scatter(np.linspace(0, 90, 90), BaseCV2, marker='v', s=20, color='C0',label = 'SVM Baseline Method')
    ax2.scatter(np.linspace(0, 90, 90), CV2, marker='^', s=20, color='C1',label = 'XGBoost with SID Features')
    ax2.scatter(np.linspace(0, 90, 90), S_CV2, marker='p', s=20, color='C4', label = 'SMOTE XGBoost with SID Features')
    ax2.plot([0, 90],[0, 0], '--', linewidth=4, color='C3', label='Chance')
    ax2.plot([25, 25],[0.35, 0.57], linewidth=2, color='C2')
    ax2.plot([75, 75],[0.2, 0.5], linewidth=2, color='C2', label="Q1, Q3")
    ax2.legend(loc = (0.02, 0.08), fancybox=True, framealpha=0.5, fontsize=9)
    ax2.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax2.set_ylabel('Coefficient of Variation\nfor Log-transformed Data')

    ax3 = fig.add_subplot(223)
    ax3.set_title("S. cerevisiae Yeast {}.{}:{}".format(ratio3[0],ratio3[2], ratio3[-1]))
    ax3.scatter(np.linspace(0, 90, 90), BaseCV3, marker='v', s=20, color='C0',label = 'SVM Baseline Method')
    ax3.scatter(np.linspace(0, 90, 90), CV3, marker='^', s=20, color='C1',label = 'XGBoost with SID Features')
    ax3.scatter(np.linspace(0, 90, 90), S_CV3, marker='p', s=20, color='C4', label = 'SMOTE XGBoost with SID Features')
    ax3.plot([0, 90],[0, 0], '--', linewidth=4, color='C3', label='Chance')
    ax3.plot([25, 25],[0.52, 0.7], linewidth=2, color='C2')
    ax3.plot([75, 75],[0.4, 0.72], linewidth=2, color='C2', label="Q1, Q3")
    ax3.legend(loc=(0.02, 0.08), fancybox=True, framealpha=0.5, fontsize=9)
    ax3.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax3.set_ylabel('Coefficient of Variation\nfor Log-transformed Data')
    
    ax4 = fig.add_subplot(224)
    ax4.set_title("S. cerevisiae Yeast {}:{}".format(ratio4[0], ratio4[-1]))
    ax4.scatter(np.linspace(0, 90, 90), BaseCV4, marker='v', s=20, color='C0',label = 'SVM Baseline Method')
    ax4.scatter(np.linspace(0, 90, 90), CV4, marker='^', s=20, color='C1',label = 'XGBoost with SID Features')
    ax4.scatter(np.linspace(0, 90, 90), S_CV4, marker='p', s=20, color='C4', label = 'SMOTE XGBoost with SID Features')
    ax4.plot([0, 90],[0, 0], '--', linewidth=4, color='C3', label='Chance')
    ax4.plot([25, 25],[0.55, 0.7], linewidth=2, color='C2')
    ax4.plot([75, 75],[0.38, 0.75], linewidth=2, color='C2', label="Q1, Q3")
    ax4.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax4.legend(loc=(0.02, 0.08), fancybox=True, framealpha=0.5, fontsize=9)
    # ax4.legend(bbox_to_anchor=(0, 1.01, 1, .1), ncol =2, mode="expand", fancybox=True, framealpha=0.5)
    ax4.set_ylabel('Coefficient of Variation\nfor Log-transformed Data')

    plt.tight_layout()
    plt.subplots_adjust(wspace=0.2, hspace=0.25)

    plt.savefig("Fig_5.eps", dpi=300, bbox_inches='tight')
    # plt.savefig("Res/Compare_RealCV.pdf", dpi=300, bbox_inches='tight')
    plt.savefig("Compare_RealCV.png", dpi=300, bbox_inches='tight')

    plt.show()


