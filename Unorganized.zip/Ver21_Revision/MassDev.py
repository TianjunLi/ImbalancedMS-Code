# %%
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import gridspec as GS
import seaborn as sns
from scipy import stats as ss
from sklearn import preprocessing

data = "../Data/L_H-1_1.csv"

Data = pd.read_csv(data)

MassDev = Data['MassDev']

MassDev = np.asarray(MassDev)

NormalizedMass = preprocessing.StandardScaler().fit_transform(MassDev.reshape(-1,1))


NormalizedMass2 = NormalizedMass.reshape(1,-1)[0]
# %%

print (np.min(NormalizedMass2))
print (np.median(NormalizedMass2))
Na = NormalizedMass2[NormalizedMass2<1]
print (np.mean(Na))
print (np.median(Na))
print (ss.mode(Na)[0][0])

# %%
Mass_DM = ss.gaussian_kde(NormalizedMass2)

_, bins = np.histogram(NormalizedMass2, bins=15, density=True)

# plt.plot(bins, Mass_DM(bins))

# Making Density more beautiful
DensityValues = Mass_DM(bins).tolist()
AddValue = (DensityValues[0]+DensityValues[1])/2

NewValues = np.zeros(len(DensityValues)+2)
NewValues[1] = DensityValues[0]
NewValues[2] = AddValue
NewValues[3:] = DensityValues[1:]


NewBins = np.zeros(len(bins)+2)
NewBins[0] = bins[0]
NewBins[1] = (bins[0]+bins[1])/2
NewBins[2] = bins[1]
NewBins[3] = (bins[1]+bins[2])/2
NewBins[4:] = bins[2:]


from matplotlib import gridspec as gridspec
from matplotlib.font_manager import FontProperties
font = FontProperties()
font.set_size(14)
font.set_weight('bold')
# Plotting the mass deviation value versus the corresponding scan
fig = plt.figure(figsize=(9, 2.7))
gs = gridspec.GridSpec(1,4)

ax1 = fig.add_subplot(gs[0, :2])
# plt.title("Distribution of Mass Deviation, Standardized", fontsize=14, fontname="serif")
ax1.plot(NormalizedMass, 'o', ms=7, mec='orange', mew='1.5', mfc='none')
# ax1.set_xlabel("Scan number")
ax1.set_ylabel("Standardized MassDev")
ax1.text(-230, 7.1, 'a', fontproperties=font)

# plt.savefig("Results/MassDev.eps", bbox_inches="tight")

ax2 = fig.add_subplot(gs[0, 2:])
# plt.title("Histogram for the Standardized Distribution", fontsize=14, fontname="serif")
from scipy import interp
int_x = np.linspace(-.5, np.max(NormalizedMass), 100)
int_y = interp(int_x, NewBins, NewValues)

# ax2.axhline(0, color='C0')
ax2.hist(NormalizedMass, bins=12, density = True, alpha=0.6, color='orange', label='Histogram')
# ax2.plot(NewBins, NewValues, color='r')
ax2.plot(int_x, int_y, color='C0', lw=3, label='Gaussian KDE')
ax2.axvline(-0.13, ymin=0.02, ymax = 0.98, color='C3', linestyle='--', linewidth=3, label=r'Global Max $\approx$ -0.13')
ax2.axvline(0.6, ymin=0.03, ymax=0.15, linewidth=3, color='red', label='Threshold')
ax2.legend()
# ax2.plot(0.5, 0, "|", color='red', markersize=20, mew=3)
ax2.set_ylim(-0.1, 1.7)
ax2.set_xlabel("Value")
ax2.set_ylabel("Frequency")
ax2.text(-1.3, 1.7, 'b', fontproperties=font)

# plt.savefig("Results/MassDev-Hist.eps", bbox_inches="tight")

# ax3 = fig.add_subplot(gs[0,3])
# # plt.title("Density Map for the Standardized Distribution", fontsize=14, fontname="serif")
# ax3 = sns.distplot(NormalizedMass2,bins=12, norm_hist=True)
# # ax3.plot(NewBins, NewValues)
# # ax3.plot(0.5, 0, "|", color='red', markersize=20, mew=3)
# ax3.set_xlabel("Value", fontsize=12)
# ax3.set_ylabel("Probability density", fontsize=12)
# ax3.text(-1.3, 1.75, 'c', fontproperties=font)
plt.tight_layout()
# # plt.savefig("Results/MassDev_Density.eps", bbox_inches="tight")
plt.subplots_adjust(wspace=0.35)
plt.savefig("MassDev.pdf", dpi=300, bbox_inches='tight')
plt.show()

# Plotting the density map of mass deviation

