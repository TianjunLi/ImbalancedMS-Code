# %%
from sklearn.externals import joblib
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

def GainWeight(estimator):
    weightdict = estimator.get_booster().get_score(importance_type = 'total_gain')
    wdict= sorted(weightdict.items(), key=lambda d:np.int(d[0][1::]), reverse = False)
    FeatureName = []
    FeatureGain = []
    for i in range(len(wdict)):
        FeatureName.append(np.int(wdict[i][0][1::]))
        FeatureGain.append(wdict[i][1])
    return FeatureName, FeatureGain


# %%
if __name__ == "__main__":
    normalclf = joblib.load('SavedModels/XGB_SID.pkl')
    smoteclf = joblib.load('SavedModels/S_XGB_SID.pkl')

    name, normalweight = GainWeight(normalclf)
    _, smoteweight = GainWeight(smoteclf)

    df = pd.DataFrame()
    df = df.assign(
        Name=["MassDev", "PPR", "S/N", "IsoDev_L1", "IsoDev_L2", "IsoDev_L3", "IsoDev_H1", "IsoDev_H2", "IsoDev_H3", "SIDsum", "SID0", "SID1", "SID2"]
    , Gain_Normal = normalweight, Gain_SMOTE = smoteweight)

    df.to_csv("FeatureGain_SMOTE.csv", index=None)

    # Y_ticks = np.arange(0, 14)
    # plt.figure(figsize=(14,5))
    # plt.subplot(1,2,1)
    # plt.title("Xgboost Classifier Feature Weights")
    # for i in range(len(normalname)):
    #     plt.barh(normalname[i], normalweight[i],height=0.4)
    #     plt.text(normalweight[i], normalname[i], "%s"%(round(normalweight[i],2)), va='center')
    # plt.text(-0,13.1,"Feature Names",ha='center', color="blue")
    # plt.yticks(Y_ticks)
    # plt.yticks(np.arange(0,13))
    # ax = plt.gca()
    # ax.set_yticklabels(("MassDev", "PPR", "S/N", "IL1", "IL2", "IL3", "IH1", "IH2", "IH3", r"$\mathrm{SID_{sum}}$", r"$\mathrm{SID}_0$", r"$\mathrm{SID_1}$", r"$\mathrm{SID}_2$"))
    # # plt.ylim(-0.5,8.5)
    # plt.xlim(0, np.max(normalweight)+1.5) #22
    # plt.xticks([])
    # plt.xlabel("Feature Gain")

    # plt.subplot(1,2,2)
    # plt.title("SMOTE Xgboost Classifier Feature Weights")
    # for i in range(len(smotename)):
    #     plt.barh(smotename[i], smoteweight[i],height=0.4)
    #     plt.text(smoteweight[i], smotename[i], "%s"%(round(smoteweight[i],2)), va='center')
    # plt.text(-0,13.1,"Feature Names",ha='center', color="blue")
    # plt.yticks(Y_ticks)
    # plt.yticks(np.arange(0,13))
    # ax = plt.gca()
    # ax.set_yticklabels(("MassDev", "PPR", "S/N", "IL1", "IL2", "IL3", "IH1", "IH2", "IH3", r"$\mathrm{SID_{sum}}$", r"$\mathrm{SID}_0$", r"$\mathrm{SID_1}$", r"$\mathrm{SID}_2$"))
    # # plt.ylim(-0.5,8.5)
    # plt.xlim(0, np.max(smoteweight)+1.5) #22
    # plt.xticks([])
    # plt.xlabel("Feature Gain")

    # # plt.grid()
    # plt.tight_layout()

    # plt.show()

