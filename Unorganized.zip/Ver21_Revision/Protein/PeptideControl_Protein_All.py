# %%
import warnings
from collections import defaultdict

import numpy as np
import pandas as pd
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler
from matplotlib import pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

from Func_LoadData import LoadNormalData, LoadSIDData
from Func_LoadModel import LoadModel


def SortDesc(vector):
    """
    vector: The needed sorted input
    Returns:
            SortIndex: The index with sorted results
            SortValue: The sorted results, desc
    """
    SortResult = sorted(enumerate(vector), key=lambda x:x[1], reverse=True)
    length = len(SortResult)
    #Get the index and the value
    SortIndex = []
    SortValue = []
    for i in range(length):
        SortIndex.append(SortResult[i][0])
        SortValue.append(SortResult[i][1])
        
    return SortIndex, SortValue

def GetProteinInfo(Data):
    # Get all the protein names
    AllProteinNames = Data['protein'].tolist()
    # Get the same protein names and its corresponding index
    ProteinDict = defaultdict(list)
    for k,va in [(v,i) for i,v in enumerate(AllProteinNames)]:
        ProteinDict[k].append(va)
    # Protein Name
    ProteinName = list(ProteinDict.keys())
    # Get each unique protein number
    ProteinAmount = []
    # Get each unique protein corresponding index
    ProteinIndex = []
    for value in list(ProteinDict.values()):
        ProteinAmount.append(len(value))
        ProteinIndex.append(value)

    return ProteinName, ProteinAmount, ProteinIndex

def GetProtein(Data, ProteinIndex, index):
    NeedIndex = ProteinIndex[index]
    Protein = Data.loc[NeedIndex]
    Ratio = np.asarray(Protein['asap mean'])
    return Protein, Ratio

def GetAssess(Protein):
    Assessed = Protein[Protein['XGBPred']==1]
    Ratios = np.asarray(Assessed['asap mean'])
    return Ratios, len(Ratios), np.mean(Ratios), np.std(Ratios)

def GetPredRes(datapath):
    xgbclf = LoadModel('smote-sidxgb')
    _, SIDData = LoadSIDData(datapath)
    SIDData = StandardScaler().fit_transform(SIDData)
    XGBPred = xgbclf.predict(SIDData)
    return XGBPred

def PlotDetails(datapath, ProteinOrder):
    XGBPred = GetPredRes(datapath)
    Data = pd.read_csv(datapath)
    Data = Data.assign(XGBPred = XGBPred)
    ProteinName, ProteinAmount, ProteinIndex = GetProteinInfo(Data)
    SI, SV = SortDesc(ProteinAmount)
    ProteinData, Ori_Asap = GetProtein(Data, ProteinIndex, SI[ProteinOrder])
    Assed_Ratios, Assed_Len, Assed_Mean, Assed_Std = GetAssess(ProteinData)

    AssDict = {}
    AssDict['Protein'] = [ProteinName[SI[ProteinOrder]]]
    AssDict['Ori_Number'] = [len(Ori_Asap)]
    AssDict['Assessed Num'] = [Assed_Len]

    AssDict['Ori_Mean'] = [np.mean(Ori_Asap)]
    AssDict['Ori_Std'] = [np.std(Ori_Asap)]

    AssDict['Assessed Mean'] = [Assed_Mean]
    AssDict['Assessed Std'] = [Assed_Std]

    df = pd.DataFrame(AssDict, index=None, columns = ['Protein', 'Ori_Number', 'Assessed Num', 'Assessed Num', 'Ori_Mean', 'Ori_Std', 'Assessed Mean', 'Assessed Std'])

    return ProteinName[SI[ProteinOrder]], Ori_Asap, Assed_Ratios, df


# %%
if __name__ == "__main__":
# 目标： 根据结果挑几个好的出来画图 over 每个比例的挑3-4个，要求接近groundtruth
    datapath1 = '../../Data/L_H-1-5_1.csv'
    gt = 1.5
    Top = 27
    NameList = []
    RatioList = []
    AssedRatioList = []
    for i in range(Top):
        TmpName, TmpRatio, TmpAR, _ = PlotDetails(datapath1, i)
        NameList.append(TmpName)
        RatioList.append(TmpRatio)
        AssedRatioList.append(TmpAR)

    print (NameList)
	
	# only for 1.5:1 Top to 27
    Top=20
    Need = np.asarray([3, 4, 5, 6, 7, 8, 9, 10, 13, 14, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26])
    NameList = np.asarray(NameList)[Need]
    print (NameList)
    RatioList = np.asarray(RatioList)[Need]
    AssedRatioList = np.asarray(AssedRatioList)[Need]

    start=1
    step=3
    num=20

    pos1 = np.arange(0,num)*step+start
    pos2 = np.arange(1,num+1)*step+start-2

    fig = plt.figure(figsize=(9, 5))
    ax = fig.add_subplot(111)
    bplot1 = ax.boxplot(RatioList, positions = pos1, widths=0.9, patch_artist=True, showfliers=False, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'r'})
    bplot2 = ax.boxplot(AssedRatioList, positions = pos2, widths=0.9,patch_artist=True,showfliers=False, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'b'})

    ax.axhline(gt, color='r')

    for patch in bplot1['boxes']:
        patch.set_facecolor('pink')
    for patch in bplot2['boxes']:
        patch.set_facecolor('lightgreen')
        patch.set_alpha(0.5)

    legend_elements = [Patch(facecolor='pink', edgecolor='black',\
        label='Without Assessed'),
        Patch(facecolor='lightgreen', edgecolor='black',\
        label='Assessed'),
        Line2D([0], [0], marker='o', linewidth=0, label='Mean Value',\
            markerfacecolor='r'),
        Line2D([0], [0], marker='o', linewidth=0, label='Mean Value',\
            markerfacecolor='b')]
    

    ax.legend(handles=legend_elements, shadow=True, bbox_to_anchor=(0., 1.02, 1., .102), loc='lower left', ncol=4, mode="expand", borderaxespad=0.)
    ax.set_xticks((pos1+pos2)/2)
    ax.set_xticklabels(NameList, rotation=45) 
    ax.set_xlim(-1, 61)

    plt.tight_layout()
    # plt.savefig("1-5_1-Protein.png", bbox_inches='tight')

    plt.show()
