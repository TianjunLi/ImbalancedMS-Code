from sklearn.externals import joblib
import warnings

def LoadModel(type):
    '''
    type = 'sidxgb', 'smote-sidxgb', 'xgb', 'smote-xgb','base'
    '''
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        if type == 'sidxgb':
            clf = joblib.load('../SavedModels/XGB_SID.pkl')
        elif type == 'smote-sidxgb':
            clf = joblib.load('../SavedModels/S_XGB_SID.pkl')
        elif type == 'xgb':
            clf = joblib.load('../SavedModels/XGB_Normal.pkl')
        elif type == 'smote-xgb':
            clf = joblib.load('../SavedModels/S_XGB_Normal.pkl')
        elif type == 'base':
            clf = joblib.load('../SavedModels/Base_SVM.pkl')
    return clf
