# %%
import warnings
from collections import defaultdict

import numpy as np
import pandas as pd
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler
from matplotlib import pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

from Func_LoadData import LoadNormalData, LoadSIDData
from Func_LoadModel import LoadModel


def SortDesc(vector):
    """
    vector: The needed sorted input
    Returns:
            SortIndex: The index with sorted results
            SortValue: The sorted results, desc
    """
    SortResult = sorted(enumerate(vector), key=lambda x:x[1], reverse=True)
    length = len(SortResult)
    #Get the index and the value
    SortIndex = []
    SortValue = []
    for i in range(length):
        SortIndex.append(SortResult[i][0])
        SortValue.append(SortResult[i][1])
        
    return SortIndex, SortValue

def GetProteinInfo(Data):
    # Get all the protein names
    AllProteinNames = Data['protein'].tolist()
    # Get the same protein names and its corresponding index
    ProteinDict = defaultdict(list)
    for k,va in [(v,i) for i,v in enumerate(AllProteinNames)]:
        ProteinDict[k].append(va)
    # Protein Name
    ProteinName = list(ProteinDict.keys())
    # Get each unique protein number
    ProteinAmount = []
    # Get each unique protein corresponding index
    ProteinIndex = []
    for value in list(ProteinDict.values()):
        ProteinAmount.append(len(value))
        ProteinIndex.append(value)

    return ProteinName, ProteinAmount, ProteinIndex

def GetProtein(Data, ProteinIndex, index):
    NeedIndex = ProteinIndex[index]
    Protein = Data.loc[NeedIndex]
    Ratio = np.asarray(Protein['asap mean'])
    return Protein, Ratio

def GetAssess(Protein):
    Assessed = Protein[Protein['XGBPred']==1]
    Ratios = np.asarray(Assessed['asap mean'])
    return Ratios, len(Ratios), np.mean(Ratios), np.std(Ratios)

def GetPredRes(datapath):
    xgbclf = LoadModel('smote-sidxgb')
    _, SIDData = LoadSIDData(datapath)
    SIDData = StandardScaler().fit_transform(SIDData)
    XGBPred = xgbclf.predict(SIDData)
    return XGBPred

def PlotDetails(datapath, ProteinOrder):
    XGBPred = GetPredRes(datapath)
    Data = pd.read_csv(datapath)
    Data = Data.assign(XGBPred = XGBPred)
    ProteinName, ProteinAmount, ProteinIndex = GetProteinInfo(Data)
    SI, SV = SortDesc(ProteinAmount)
    ProteinData, Ori_Asap = GetProtein(Data, ProteinIndex, SI[ProteinOrder])
    Assed_Ratios, Assed_Len, Assed_Mean, Assed_Std = GetAssess(ProteinData)

    AssDict = {}
    AssDict['Protein'] = [ProteinName[SI[ProteinOrder]]]
    AssDict['Ori_Number'] = [len(Ori_Asap)]
    AssDict['Assessed Num'] = [Assed_Len]

    AssDict['Ori_Mean'] = [np.mean(Ori_Asap)]
    AssDict['Ori_Std'] = [np.std(Ori_Asap)]

    AssDict['Assessed Mean'] = [Assed_Mean]
    AssDict['Assessed Std'] = [Assed_Std]

    df = pd.DataFrame(AssDict, index=None, columns = ['Protein', 'Ori_Number', 'Assessed Num', 'Assessed Num', 'Ori_Mean', 'Ori_Std', 'Assessed Mean', 'Assessed Std'])

    return ProteinName[SI[ProteinOrder]], Ori_Asap, Assed_Ratios, df


# %%
if __name__ == "__main__":
    # Get the first data
    datapath1 = '../../Data/L_H-1_1.csv'
    Top1 = 20
    NameList1 = []
    RatioList1 = []
    AssedRatioList1 = []
    DFList1 = []
    for i in range(Top1):
        TmpName, TmpRatio, TmpAR, TmpDF = PlotDetails(datapath1, i)
        NameList1.append(TmpName)
        RatioList1.append(TmpRatio)
        AssedRatioList1.append(TmpAR)
        DFList1.append(TmpDF)
    Selected1 = np.array([0,16]) # 1:1
    NameList1 = np.asarray(NameList1)[Selected1]
    RatioList1 = np.asarray(RatioList1)[Selected1]
    AssedRatioList1 = np.asarray(AssedRatioList1)[Selected1]
    DF1 = DFList1[0]
    DF2 = DFList1[16]

    # Get the second data
    datapath2 = '../../Data/L_H-1-5_1.csv'
    Top2 = 27
    NameList2 = []
    RatioList2 = []
    AssedRatioList2 = []
    DFList2 = []
    for i in range(Top2):
        TmpName, TmpRatio, TmpAR, TmpDF = PlotDetails(datapath2, i)
        NameList2.append(TmpName)
        RatioList2.append(TmpRatio)
        AssedRatioList2.append(TmpAR)
        DFList2.append(TmpDF)
    Top2=20
    Selected2 = np.array([6,13]) # 1.5:1
    NameList2 = np.asarray(NameList2)[Selected2]
    RatioList2 = np.asarray(RatioList2)[Selected2]
    AssedRatioList2 = np.asarray(AssedRatioList2)[Selected2]
    DF3 = DFList2[6]
    DF4 = DFList2[13]

    frames = [DF1, DF2, DF3, DF4]
    TotalDF = pd.concat(frames, keys=['{} in 1:1'.format(NameList1[0]), '{} in 1:1'.format(NameList1[1]), '{} in 1.5:1'.format(NameList2[0]), '{} in 1.5:1'.format(NameList2[1])])

    TotalDF.to_csv("Protein.csv", index=None)

    start=1
    step=3
    num=2

    pos1 = np.arange(0,num)*step+start
    pos2 = np.arange(1,num+1)*step+start-2

    fig = plt.figure(figsize=(8, 3))
    ax1 = fig.add_subplot(121)
    ax1.set_title("Proteins in 1:1 Sample")
    bplot1 = ax1.boxplot(RatioList1, positions = pos1, widths=0.7, patch_artist=True, showfliers=False, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'r', 'markeredgecolor':'C0'}, medianprops={'linewidth':2, 'color':'C4'})
    bplot2 = ax1.boxplot(AssedRatioList1, positions = pos2, widths=0.7,patch_artist=True,showfliers=False, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'r', 'markeredgecolor':'C0'}, medianprops={'linewidth':2, 'color':'C4'})
    legend_elements = [Patch(facecolor='pink', edgecolor='black',\
        label='Without Assessed'),
        Patch(facecolor='lightgreen', edgecolor='black',\
        label='Assessed'),
        Line2D([0], [0], marker='o', linewidth=0, label='Mean Value',\
            markerfacecolor='r'),
        Line2D([0], [0], color='C4',linewidth=2, label='Median Value')]
    ax1.axhline(1)
    ax1.legend(handles=legend_elements, shadow=True, bbox_to_anchor=(0.01, 0.78, 0.975, .1), loc='lower left', ncol=2, mode="expand", borderaxespad=0.)
    ax1.set_ylim(0.48, 2.15)
    ax1.set_xticks((pos1+pos2)/2)
    ax1.set_xticklabels(NameList1) 
    ax1.set_xlim(np.min(pos1)-1, np.max(pos2)+1)
    ax1.set_ylabel('Peptide ratio')



    ax2 = fig.add_subplot(122)
    ax2.set_title("Proteins in 1.5:1 Sample")
    bplot3 = ax2.boxplot(RatioList2, positions = pos1, widths=0.7, patch_artist=True, showfliers=False, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'r', 'markeredgecolor':'C0'}, medianprops={'linewidth':2, 'color':'C4'})
    bplot4 = ax2.boxplot(AssedRatioList2, positions = pos2, widths=0.7,patch_artist=True,showfliers=False, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'r', 'markeredgecolor':'C0'}, medianprops={'linewidth':2, 'color':'C4'})
    legend_elements = [Patch(facecolor='pink', edgecolor='black',\
        label='Without Assessed'),
        Patch(facecolor='lightgreen', edgecolor='black',\
        label='Assessed'),
        Line2D([0], [0], marker='o', linewidth=0, label='Mean Value',\
            markerfacecolor='r'),
        Line2D([0], [0], color='C4',linewidth=2, label='Median Value')]
    ax2.axhline(1.5)
    ax2.legend(handles=legend_elements, shadow=True, bbox_to_anchor=(0.01, 0.78, 0.975, .1), loc='lower left', ncol=2, mode="expand", borderaxespad=0.)
    ax2.set_ylim(-0.02, 3.6)
    ax2.set_xticks((pos1+pos2)/2)
    ax2.set_xticklabels(NameList2) 
    ax2.set_xlim(np.min(pos1)-1, np.max(pos2)+1)
    ax2.set_ylabel('Peptide ratio')

    for bplot in (bplot1, bplot3):
        for patch in bplot['boxes']:
            patch.set_facecolor('pink')
            patch.set_alpha(0.5)
    for bplot in (bplot2, bplot4):
        for patch in bplot['boxes']:
            patch.set_facecolor('lightgreen')
            patch.set_alpha(0.5)

    plt.tight_layout()
    # plt.savefig("Protein.png", dpi=300, bbox_inches='tight')
    # plt.savefig("Protein.eps", dpi=300, bbox_inches='tight')
    # plt.savefig("Protein.pdf", dpi=300, bbox_inches='tight')

    plt.show()