# %%
import numpy as np
import pandas as pd

# %%
def GetPatternList(datapath):
    Data = pd.read_csv(datapath)
    Patterns = Data['IsotopicPattern']
    MonoPattern = []
    for i in range(Patterns.shape[0]):
        TmpList = Patterns[i].split(',')
        MonoPattern.append(float(TmpList[1]))

    return MonoPattern

def GetSIDs(datapath, MonoPattern):
    Data = pd.read_csv(datapath)
    SIPsum = Data['SIP']
    SIPsum.replace(-30, 0)
    SIP0 = Data['Scan0IP']
    SIP0.replace(-30, 0)
    SIP1 = Data['Scan1IP']
    SIP1.replace(-30, 0)
    SIP2 = Data['Scan2IP']
    SIP2.replace(-30, 0)

    SIDsum = (SIPsum-MonoPattern) / MonoPattern
    SID0 = (SIP0-MonoPattern) / MonoPattern
    SID1 = (SIP1-MonoPattern) / MonoPattern
    SID2 = (SIP2-MonoPattern) / MonoPattern

    Data = Data.assign(SIDsum = SIDsum, SID0 = SID0, SID1 = SID1, SID2=SID2)

    return Data


if __name__ == "__main__":

    datapath = '../../Data/L_H-4_1.csv'
    
    MonoPattern = GetPatternList(datapath)
    NewData = GetSIDs(datapath, MonoPattern)
    NewData.to_csv(datapath)



    # np.savetxt('FeatureChanging_New/MonoPattern_%s.txt'%(ratio), MonoPattern, fmt='%.5f')

