# %%
import numpy as np
import pandas as pd

from matplotlib import pyplot as plt
from sklearn import svm
from sklearn.externals import joblib
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from imblearn.metrics import geometric_mean_score as g_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from xgboost.sklearn import XGBClassifier


def LoadSIDData(datapath):
    data = pd.read_csv(datapath)

    TrainingSet = np.zeros((data.shape[0],13))
    TrainingSet[:,0] = np.asarray(data['MassDev'])
    TrainingSet[:,1] = np.asarray(data['PPR'])
    TrainingSet[:,2] = np.asarray(data['S/N'])
    TrainingSet[:,3] = np.asarray(data['IsoDev1_Light'])
    TrainingSet[:,4] = np.asarray(data['IsoDev2_Light'])
    TrainingSet[:,5] = np.asarray(data['IsoDev3_Light'])
    TrainingSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    TrainingSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    TrainingSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 
    TrainingSet[:,9] = np.asarray(data['SIDsum'])  
    TrainingSet[:,10] = np.asarray(data['SID0']) 
    TrainingSet[:,11] = np.asarray(data['SID1']) 
    TrainingSet[:,12] = np.asarray(data['SID2']) 

    TrainingLabel = np.asarray(data['FinalLabel'])

    return TrainingSet, TrainingLabel

def LoadNormalData(datapath):
    data = pd.read_csv(datapath)

    TrainingSet = np.zeros((data.shape[0],9))
    TrainingSet[:,0] = np.asarray(data['MassDev'])
    TrainingSet[:,1] = np.asarray(data['PPR'])
    TrainingSet[:,2] = np.asarray(data['S/N'])
    TrainingSet[:,3] = np.asarray(data['IsoDev1_Light'])
    TrainingSet[:,4] = np.asarray(data['IsoDev2_Light'])
    TrainingSet[:,5] = np.asarray(data['IsoDev3_Light'])
    TrainingSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    TrainingSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    TrainingSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 

    TrainingLabel = np.asarray(data['FinalLabel'])

    return TrainingSet, TrainingLabel

# Load Data
datafile = "../Data/L_H-1_1.csv"
    # Get Training Data with Label
Data, targets = LoadSIDData(datafile)
Data = StandardScaler().fit_transform(Data)
_, xgbX_res, _, xgby_test = train_test_split(Data, targets, test_size=0.25, random_state=2)


Data, targets = LoadNormalData(datafile)
Data = StandardScaler().fit_transform(Data)
_, baseX_res, _, basey_test = train_test_split(Data, targets, test_size=0.25, random_state=2)




xgbclf = joblib.load("SavedModels/S_XGB_SID.pkl")
baseclf = joblib.load("SavedModels/Base_SVM.pkl")

Xgb_Label = xgbclf.predict(xgbX_res)
base_Label = baseclf.predict(baseX_res)

# %%
# Accuracy Score:
print ("Accuracy Score (Xgb, base): ")
Xgb_Accu = accuracy_score(xgby_test, Xgb_Label)
print (Xgb_Accu)
Base_Accu = accuracy_score(basey_test, base_Label)
print (Base_Accu)

# %%
# Precision Score:
print ("Precision Score (Xgb, base): ")
Xgb_Pre = precision_score(xgby_test, Xgb_Label, average='weighted')
print (Xgb_Pre)
Base_Pre = precision_score(basey_test, base_Label, average='weighted')
print (Base_Pre)

# %%
# Recall Score:
print ("Recall Score (Xgb, base): ")
Xgb_Recall = recall_score(xgby_test, Xgb_Label, average='weighted')
print (Xgb_Recall)
Svm_Recall = recall_score(basey_test, base_Label, average='weighted')
print (Svm_Recall)

# %%
# F-measure
print ("F1 Score (Xgb, base): ")
Xgb_F = f1_score(xgby_test, Xgb_Label, average='weighted')
print (Xgb_F)
Svm_F = f1_score(basey_test, base_Label, average='weighted')
print (Svm_F)

# %%
# G-Mean
print ("G-mean (Xgb, base): ")
Xgb_G = g_score(xgby_test, Xgb_Label, average='weighted')
print (Xgb_G)
Svm_G = g_score(basey_test, base_Label, average='weighted')
print (Svm_G)