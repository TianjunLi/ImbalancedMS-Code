# %%
"""
==========================================
Applying different Classifier To Peptides
==========================================
"""

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler

from Func_LoadData import LoadSIDData, LoadNormalData
from Func_LoadModel import LoadModel

def PredictWithOrder(data, estimator, sorttype):
    '''
    sorttype: 'asc','desc'
    return: SortIndex, SortValue
    '''
    y_pred_prob = estimator.predict_proba(data)[:,1]
    iternum = y_pred_prob.shape[0]

    SortIndex = []
    SortValue = []
    if sorttype == 'asc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1])
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    elif sorttype == 'desc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1], reverse=True)
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    return SortIndex, np.asarray(SortValue)

def GetPredictRes(dataratio, datatype, estimator):
    '''
    datatype: 'sid', 'normal'
    '''
    datapath = "../Data/L_H-%s.csv"%(dataratio)
    if datatype == 'sid':
        AsapRatio, Data = LoadSIDData(datapath)
    elif datatype == 'normal':
        AsapRatio, Data = LoadNormalData(datapath)
    
    AsapRatio = np.log2(AsapRatio)

    Data = StandardScaler().fit_transform(Data)

    AscIndex, AscValues = PredictWithOrder(Data, estimator, 'asc')

    return AsapRatio[AscIndex], AscValues[AscValues>0.5].shape[0]

def RoundNum(X, n):
    TmpX = round(X, n)
    return TmpX

def GetTable(BaseMethodRes, OurMethodRes, Threshold, n):
    '''
    Threshold: the threshold that remain the spectra, e.g., 0.7 means remain 70% spectra
    '''
    TotalNum = len(BaseMethodRes)
    T = np.int(TotalNum * (1-Threshold))
    F_BaseMethodRes = BaseMethodRes[T:]
    F_OurMethodRes = OurMethodRes[T:]

    BaseMean = np.mean(F_BaseMethodRes)
    BaseMean = RoundNum(BaseMean, n)

    BaseMode = stats.mode(F_BaseMethodRes)[0][0]
    BaseMode = RoundNum(BaseMode, n)

    BaseCV = stats.variation(F_BaseMethodRes)
    BaseCV = RoundNum(BaseCV, n)

    OurMean = np.mean(F_OurMethodRes)
    OurMean = RoundNum(OurMean, n)

    OurMode = stats.mode(F_OurMethodRes)[0][0]
    OurMode = RoundNum(OurMode, n)

    OurCV = stats.variation(F_OurMethodRes)
    OurCV = RoundNum(OurCV, n)

    OriMean = np.mean(OurMethodRes)
    OriMean = RoundNum(OriMean, n)

    OriMode = stats.mode(OurMethodRes)[0][0]
    OriMode = RoundNum(OriMode, n)

    OriCV = stats.variation(OurMethodRes)
    OriCV = RoundNum(OriCV, n)

    ResDict = {}

    ResDict['OriginalNum'] = [TotalNum]
    ResDict['RemainedNum'] = [TotalNum-T]

    ResDict['Original_Mean'] = [OriMean]
    ResDict['XGB_Mean'] = [BaseMean]
    ResDict['XGB_SID_Mean'] = [OurMean]

    ResDict['Original_Mode'] = [OriMode]
    ResDict['XGB_Mode'] = [BaseMode]
    ResDict['XGB_SID_Mode'] = [OurMode]

    ResDict['Original_CV'] = [OriCV]
    ResDict['XGB_CV'] = [BaseCV]
    ResDict['XGB_SID_CV'] = [OurCV]

    return ResDict

def GetDF(ratio, Threshold, n):
    '''
    Threshold: the threshold that remain the spectra, e.g., 0.7 means remain 70% spectra
    '''
    S_SIP_clf = LoadModel('smote-sidxgb')
    S_SIP_Res, _ = GetPredictRes(ratio, 'sid', S_SIP_clf)

    SIP_clf = LoadModel('sidxgb')
    SIP_Res, _ = GetPredictRes(ratio, 'sid', SIP_clf)

    Table = GetTable(SIP_Res, S_SIP_Res, Threshold, n)

    return pd.DataFrame(Table, index=["%s"%ratio], columns=['OriginalNum', 'RemainedNum','Original_Mean','XGB_Mean','XGB_SID_Mean','Original_Mode','XGB_Mode','XGB_SID_Mode','Original_CV','XGB_CV','XGB_SID_CV']) 

# %%
if __name__ == "__main__":
    print (__doc__)
    Threshold = 0.8
    roundnum = 2

    table1 = GetDF("1_2", Threshold, roundnum)
    table2 = GetDF("1_1", Threshold, roundnum)
    table3 = GetDF("1-5_1", Threshold, roundnum)
    table4 = GetDF("2_1", Threshold, roundnum)

    frames = [table1, table2, table3, table4]

    result = pd.concat(frames)
    
    # result.to_csv("ControlResults/OverallRes_0.7.csv")
    print (result)

