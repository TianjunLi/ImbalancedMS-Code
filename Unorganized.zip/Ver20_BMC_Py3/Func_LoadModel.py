from sklearn.externals import joblib

def LoadModel(type):
    '''
    type = 'sidxgb', 'smote-sidxgb', 'xgb', 'smote-xgb','base'
    '''
    if type == 'sidxgb':
        clf = joblib.load('SavedModels/XGB_SID.pkl')
    elif type == 'smote-sidxgb':
        clf = joblib.load('SavedModels/S_XGB_SID.pkl')
    elif type == 'xgb':
        clf = joblib.load('SavedModels/XGB_Normal.pkl')
    elif type == 'smote-xgb':
        clf = joblib.load('SavedModels/S_XGB_Normal.pkl')
    elif type == 'base':
        clf = joblib.load('SavedModels/Base_SVM.pkl')
    return clf

# def LoadModel_Same(type):
#     '''
#     type = 'sipxgb', 'smote-sipxgb', 'xgb', 'smote-xgb'
#     '''
#     if type == 'sipxgb':
#         clf = joblib.load('SavedModels/SIP_XGB_Same.pkl')
#     elif type == 'smote-sipxgb':
#         clf = joblib.load('SavedModels/S-SIP_XGB.pkl')
#     elif type == 'xgb':
#         clf = joblib.load('SavedModels/Normal_XGB_Same.pkl')
#     elif type == 'smote-xgb':
#         clf = joblib.load('SavedModels/S-Nor_XGB_Same.pkl')
#     return clf

# def LoadBaseModel(type):
#     '''
#     type = 'sip', 'normal'
#     '''
#     if type == 'sip':
#         clf = joblib.load('SavedModels/Base_SIP_SVM.pkl')
#     elif type == 'normal':
#         clf = joblib.load('SavedModels/Base_SVM.pkl')
#     return clf

# def LoadGSCVModel(type):
#     '''
#     type = 'sipxgb', 'smote-sipxgb', 'xgb', 'smote-xgb'
#     '''
#     if type == 'sipxgb':
#         clf = joblib.load('SavedModels/XGB_GSCV_SIP.pkl')
#     elif type == 'smote-sipxgb':
#         clf = joblib.load('SavedModels/SMOTE_XGB_GSCV_SIP.pkl')
#     elif type == 'xgb':
#         clf = joblib.load('SavedModels/XGB_GSCV_Normal.pkl')
#     elif type == 'smote-xgb':
#         clf = joblib.load('SavedModels/SMOTE_XGB_GSCV_Normal.pkl')
#     return clf
