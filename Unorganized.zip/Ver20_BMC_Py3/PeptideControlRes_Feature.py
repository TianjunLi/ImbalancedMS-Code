# %%
"""
==========================================
Applying different Classifier To Peptides
==========================================
"""

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler

from Func_LoadData import LoadSIDData, LoadNormalData
from Func_LoadModel import LoadModel

def PredictWithOrder(data, estimator, sorttype):
    '''
    sorttype: 'asc','desc'
    return: SortIndex, SortValue
    '''
    y_pred_prob = estimator.predict_proba(data)[:,1]
    iternum = y_pred_prob.shape[0]

    SortIndex = []
    SortValue = []
    if sorttype == 'asc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1])
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    elif sorttype == 'desc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1], reverse=True)
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    return SortIndex, np.asarray(SortValue)

def GetPredictRes(dataratio, datatype, estimator):
    '''
    datatype: 'sid', 'normal'
    '''
    datapath = "../Data/L_H-%s.csv"%(dataratio)
    if datatype == 'sid':
        AsapRatio, Data = LoadSIDData(datapath)
    elif datatype == 'normal':
        AsapRatio, Data = LoadNormalData(datapath)
    
    AsapRatio = np.log2(AsapRatio)

    Data = StandardScaler().fit_transform(Data)

    AscIndex, AscValues = PredictWithOrder(Data, estimator, 'asc')

    return AsapRatio[AscIndex], AscValues[AscValues>0.5].shape[0]

def GetPickedRes(RatioList):
    num = RatioList.shape[0]
    CVList = []
    foldnum = np.int((1/100)*num)
    for i in range(90):
        StartIndex = i*foldnum
        RemainedRatio = RatioList[StartIndex:]
        CVList.append(stats.variation(RemainedRatio))
    return CVList

def GetResWithRatio(ratio):
    S_SIP_clf = LoadModel('smote-sidxgb')
    S_SIP_Res, _ = GetPredictRes(ratio, 'sid', S_SIP_clf)
    S_SIPCV = GetPickedRes(S_SIP_Res)

    SIP_clf = LoadModel('smote-xgb')
    SIP_Res, _ = GetPredictRes(ratio, 'normal', SIP_clf)
    SIPCV = GetPickedRes(SIP_Res)

    return S_SIPCV, SIPCV


# %%
if __name__ == "__main__":
    print (__doc__)
    ratio1 = "1_2"
    ratio2 = "1_1"
    ratio3 = "1-5_1"
    ratio4 = "2_1"
    
    SIDCV1, CV1 = GetResWithRatio(ratio1)
    SIDCV2, CV2 = GetResWithRatio(ratio2)
    SIDCV3, CV3 = GetResWithRatio(ratio3)
    SIDCV4, CV4 = GetResWithRatio(ratio4)

    fig = plt.figure(figsize=(10, 6))
    ax1 = fig.add_subplot(221)
    ax1.set_title("S. cerevisiae Yeast {}:{}".format(ratio1[0], ratio1[-1]))
    ax1.scatter(np.linspace(0, 90, 90), CV1, marker='^', s=20, color='orange', label = 'SMOTE XGBoost')
    ax1.scatter(np.linspace(0, 90, 90), SIDCV1, marker='v', s=20, color='green',label = 'SMOTE XGBOOST with SID Features')
    ax1.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    ax1.legend(loc=(0.02, 0.63), shadow=True)
    ax1.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax1.set_ylabel(r'$\log_2$(Coefficient of Variation)')


    ax2 = fig.add_subplot(222)
    ax2.set_title("S. cerevisiae Yeast {}:{}".format(ratio2[0], ratio2[-1]))
    ax2.scatter(np.linspace(0, 90, 90), CV2, marker='^', s=20, color='orange', label = 'SMOTE XGBoost')
    ax2.scatter(np.linspace(0, 90, 90), SIDCV2, marker='v', s=20, color='green',label = 'SMOTE XGBOOST with SID Features')
    ax2.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    ax2.legend(loc=(0.02,0.1), shadow=True)
    ax2.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax2.set_ylabel(r'$\log_2$(Coefficient of Variation)')
    
    ax3 = fig.add_subplot(223)
    ax3.set_title("S. cerevisiae Yeast {}.{}:{}".format(ratio3[0],ratio3[2], ratio3[-1]))
    ax3.scatter(np.linspace(0, 90, 90), CV3, marker='^', s=20, color='orange', label = 'SMOTE XGBoost')
    ax3.scatter(np.linspace(0, 90, 90), SIDCV3, marker='v', s=20, color='green',label = 'SMOTE XGBOOST with SID Features')
    ax3.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    ax3.legend(loc=(0.02,0.1), shadow=True)
    ax3.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax3.set_ylabel(r'$\log_2$(Coefficient of Variation)')

    ax4 = fig.add_subplot(224)
    ax4.set_title("S. cerevisiae Yeast {}:{}".format(ratio2[0], ratio2[-1]))
    ax4.scatter(np.linspace(0, 90, 90), CV4, marker='^', s=20, color='orange', label = 'SMOTE XGBoost')
    ax4.scatter(np.linspace(0, 90, 90), SIDCV4, marker='v', s=20, color='green',label = 'SMOTE XGBOOST with SID Features')
    ax4.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    ax4.legend(loc=(0.02,0.1), shadow=True)
    ax4.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax4.set_ylabel(r'$\log_2$(Coefficient of Variation)')

    plt.tight_layout()
    plt.subplots_adjust(wspace=0.2, hspace=0.25)

    plt.savefig("ControlResults/VsSID.eps", dpi=300, bbox_inches='tight')
    plt.savefig("ControlResults/VsSID.png", dpi=300, bbox_inches='tight')

    plt.show()


