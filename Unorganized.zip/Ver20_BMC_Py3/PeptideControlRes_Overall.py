# %%
"""
==========================================
Applying different Classifier To Peptides
==========================================
"""

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from scipy import stats
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler

from Func_LoadData import LoadSIDData, LoadNormalData
from Func_LoadModel import LoadModel

def PredictWithOrder(data, estimator, sorttype):
    '''
    sorttype: 'asc','desc'
    return: SortIndex, SortValue
    '''
    y_pred_prob = estimator.predict_proba(data)[:,1]
    iternum = y_pred_prob.shape[0]

    SortIndex = []
    SortValue = []
    if sorttype == 'asc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1])
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    elif sorttype == 'desc':
        SortRes = sorted(enumerate(y_pred_prob), key=lambda x:x[1], reverse=True)
        for i in range(iternum):
            SortIndex.append(SortRes[i][0])
            SortValue.append(SortRes[i][1])
    return SortIndex, np.asarray(SortValue)

def GetPredictRes(dataratio, datatype, estimator):
    '''
    datatype: 'sid', 'normal'
    '''
    datapath = "../Data/L_H-%s.csv"%(dataratio)
    if datatype == 'sid':
        AsapRatio, Data = LoadSIDData(datapath)
    elif datatype == 'normal':
        AsapRatio, Data = LoadNormalData(datapath)
    
    AsapRatio = np.log2(AsapRatio)

    Data = StandardScaler().fit_transform(Data)

    AscIndex, AscValues = PredictWithOrder(Data, estimator, 'asc')

    return AsapRatio[AscIndex], AscValues[AscValues>0.5].shape[0]

def GetPickedRes(RatioList):
    num = RatioList.shape[0]
    CVList = []
    foldnum = np.int((1/100)*num)
    for i in range(90):
        StartIndex = i*foldnum
        RemainedRatio = RatioList[StartIndex:]
        CVList.append(stats.variation(RemainedRatio))
    return CVList

# %%
if __name__ == "__main__":
    print (__doc__)

    
    xgbclf = LoadModel('smote-sidxgb')
    Baseclf = LoadModel('base')

    ratio1 = "1_2"
    S_SIP_Res, _ = GetPredictRes(ratio1, 'sid', xgbclf)
    S_SIPCV1 = GetPickedRes(S_SIP_Res)

    BaseRes, _ = GetPredictRes(ratio1, 'normal', Baseclf)
    BaseCV1 = GetPickedRes(BaseRes)

    ratio2 = "1_1"
    S_SIP_Res, _ = GetPredictRes(ratio2, 'sid', xgbclf)
    S_SIPCV2 = GetPickedRes(S_SIP_Res)

    BaseRes, _ = GetPredictRes(ratio2, 'normal', Baseclf)
    BaseCV2 = GetPickedRes(BaseRes)

    ratio3 = "2_1"
    S_SIP_Res, _ = GetPredictRes(ratio3, 'sid', xgbclf)
    S_SIPCV3 = GetPickedRes(S_SIP_Res)

    BaseRes, _ = GetPredictRes(ratio3, 'normal', Baseclf)
    BaseCV3 = GetPickedRes(BaseRes)

    ratio4 = "1-5_1"
    
    S_SIP_Res, _ = GetPredictRes(ratio4, 'sid', xgbclf)
    S_SIPCV4 = GetPickedRes(S_SIP_Res)

    BaseRes, BaseLen = GetPredictRes(ratio4, 'normal', Baseclf)
    BaseCV4 = GetPickedRes(BaseRes)

    fig = plt.figure(figsize=(10, 6))
    ax1 = fig.add_subplot(221)
    ax1.set_title("S. cerevisiae Yeast {}:{}".format(ratio1[0], ratio1[-1]))
    ax1.scatter(np.linspace(0, 90, 90), BaseCV1, marker='^', s=20, color='orange',label = 'SVM Base Method')
    ax1.scatter(np.linspace(0, 90, 90), S_SIPCV1, marker='v', s=20, color='green', label = 'SMOTE XGB with SID Features')
    ax1.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    # ax1.text(-11, -0.555, '.', fontsize='18')
    # ax1.text(-11, -0.57, '.', fontsize='18')
    # ax1.text(-11, -0.585, '.', fontsize='18')
    # ax1.text(-11, -0.6, '.', fontsize='18')
    # ax1.text(-11, -0.615, '.', fontsize='18')
    # ax1.text(-11, -0.63, '.', fontsize='18')
    ax1.legend(loc=(0.02, 0.63), shadow=True)
    ax1.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    # ax1.set_yticks([-1, -0.9, -0.8, -0.7, -0.6, -0.5])
    # ax1.set_yticklabels([-1.0,-0.9,-0.8,-0.7,'', 0.0])
    ax1.set_ylabel(r'$\log_2$(Coefficient of Variation)')


    ax2 = fig.add_subplot(222)
    ax2.set_title("S. cerevisiae Yeast {}:{}".format(ratio2[0], ratio2[-1]))
    ax2.scatter(np.linspace(0, 90, 90), BaseCV2, marker='^', s=20, color='orange',label = 'SVM Base Method')
    ax2.scatter(np.linspace(0, 90, 90), S_SIPCV2, marker='v', s=20, color='green', label = 'SMOTE XGB with SID Features')
    ax2.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    # ax2.legend(loc='lower left')
    ax2.legend(loc = (0.02,0.1), shadow=True)
    ax2.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax2.set_ylabel(r'$\log_2$(Coefficient of Variation)')

    ax3 = fig.add_subplot(224)
    ax3.set_title("S. cerevisiae Yeast {}:{}".format(ratio3[0], ratio3[-1]))
    ax3.scatter(np.linspace(0, 90, 90), BaseCV3, marker='^', s=20, color='orange',label = 'SVM Base Method')
    ax3.scatter(np.linspace(0, 90, 90), S_SIPCV3, marker='v', s=20, color='green', label = 'SMOTE XGB with SID Features')
    ax3.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    # ax3.legend(loc='lower left')
    ax3.legend(loc=(0.02, 0.1), shadow=True)
    ax3.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    ax3.set_ylabel(r'$\log_2$(Coefficient of Variation)')
    
    ax4 = fig.add_subplot(223)
    ax4.set_title("S. cerevisiae Yeast {}.{}:{}".format(ratio4[0],ratio4[2], ratio4[-1]))
    ax4.scatter(np.linspace(0, 90, 90), BaseCV4, marker='^', s=20, color='orange',label = 'SVM Base Method')
    ax4.scatter(np.linspace(0, 90, 90), S_SIPCV4, marker='v', s=20, color='green', label = 'SMOTE XGB with SID Features')
    ax4.plot([0, 90],[0, 0], '--', linewidth=4, color='red', label='Chance')
    ax4.set_xticks([0, 10, 20, 30, 40, 50, 60, 70, 80, 90])
    # ax4.text(-11, 0.54, '.', fontsize='18')
    # ax4.text(-11, 0.56, '.', fontsize='18')
    # ax4.text(-11, 0.58, '.', fontsize='18')
    # ax4.text(-11, 0.6, '.', fontsize='18')
    # ax4.text(-11, 0.62, '.', fontsize='18')
    # ax4.text(-11, 0.64, '.', fontsize='18')
    ax4.legend(loc=(0.02, 0.1),shadow=True)
    # ax4.set_yticks([0.4, 0.6, 0.8, 1.0, 1.2])
    # ax4.set_yticklabels([0.0, '', 0.8, 1.0, 1.2])
    ax4.set_ylabel(r'$\log_2$(Coefficient of Variation)')

    plt.tight_layout()
    plt.subplots_adjust(wspace=0.2, hspace=0.25)

    plt.savefig("ControlResults/VsBase.eps", dpi=300, bbox_inches='tight')
    plt.savefig("ControlResults/VsBase.png", dpi=300, bbox_inches='tight')

    plt.show()