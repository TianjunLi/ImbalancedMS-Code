import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import StratifiedKFold, train_test_split
from xgboost.sklearn import XGBClassifier
from sklearn.svm import SVC
from scipy import interp
from sklearn.metrics import roc_curve, auc, average_precision_score, precision_recall_curve, classification_report
from matplotlib import pyplot as plt
from sklearn.externals import joblib

def LoadTrainData(datapath):
    data = pd.read_csv(datapath)

    TrainingSet = np.zeros((data.shape[0],13))
    TrainingSet[:,0] = np.asarray(data['MassDev'])
    TrainingSet[:,1] = np.asarray(data['PPR'])
    TrainingSet[:,2] = np.asarray(data['S/N'])
    TrainingSet[:,3] = np.asarray(data['IsoDev1_Light'])
    TrainingSet[:,4] = np.asarray(data['IsoDev2_Light'])
    TrainingSet[:,5] = np.asarray(data['IsoDev3_Light'])
    TrainingSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    TrainingSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    TrainingSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 
    TrainingSet[:,9] = np.asarray(data['SIDsum'])  
    TrainingSet[:,10] = np.asarray(data['SID0']) 
    TrainingSet[:,11] = np.asarray(data['SID1']) 
    TrainingSet[:,12] = np.asarray(data['SID2']) 

    TrainingLabel = np.asarray(data['FinalLabel'])

    return TrainingSet, TrainingLabel

def GetTestFoldResult(data, targets, cv, seed):
    Stratified_folder = StratifiedKFold(n_splits=cv, random_state=seed)
    FolderRes = Stratified_folder.split(data, targets)

    data = StandardScaler().fit_transform(data)

    # Get each k-fold results
    FoldXtrain = []
    Foldytrain = []

    FoldXtest = []
    Foldytest = []

    for train_index, test_index in FolderRes:
        # Original result for each fold
        X_train = data[train_index, :]
        y_train = targets[train_index]

        X_test = data[test_index, :]
        y_test = targets[test_index]
        # For each fold, resample the training one
        
        FoldXtrain.append(X_train)
        Foldytrain.append(y_train)

        FoldXtest.append(X_test)
        Foldytest.append(y_test)

    return FoldXtrain, Foldytrain, FoldXtest, Foldytest

def GetCVScore(X_trainList, y_trainList, X_testList, y_testList, estimator, cv):
    print ("=======================\nStart calculating AUC for each fold:")
    tprs = []
    aucs = []
    mean_fpr = np.linspace(0, 1, 100)
    tprlist = []
    fprlist = []

    precisionlist = []
    recalllist = []
    pres = []
    yreal = []
    yprob = []
    cv_pr = []

    reports = []
    for i in range(cv):
        X_train = X_trainList[i]
        y_train = y_trainList[i]

        X_test = X_testList[i]
        y_test = y_testList[i]

        X_res, y_res = SMOTE(random_state=2).fit_sample(X_train, y_train)

        clf = estimator
        clf.fit(X_res, y_res)
        

        y_pred = clf.predict(X_test)
        y_pred_prob = clf.predict_proba(X_test)[:, 1]
        # y_pred_prob = clf.decision_function(X_test)

        reports.append(classification_report(y_test, y_pred))
        # ROC 
        fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
        fprlist.append(fpr)
        tprlist.append(tpr)
        tprs.append(interp(mean_fpr, fpr, tpr))
        tprs[-1][0] = 0.0
        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)

        # PRC
        _precision, _recall, _ = precision_recall_curve(y_test, y_pred_prob)
        precisionlist.append(_precision)
        recalllist.append(_recall)
        pres.append(interp(mean_fpr, _recall[::-1], _precision[::-1]))
        cv_pr.append(average_precision_score(y_test, y_pred_prob))
        yreal.append(y_test)
        yprob.append(y_pred_prob)

        print ("Fold {} done".format(i+1))
    yreal = np.concatenate(yreal)
    yprob = np.concatenate(yprob)
    print ("=======================")
    return fprlist, tprlist, tprs, aucs, pres, yreal, yprob, cv_pr, precisionlist, recalllist, reports
    
def PlotROC(fprlist, tprlist, tprs, aucs, cvfold, figsize):
    print ("Ploting!")
    mean_fpr = np.linspace(0, 1, 100)
    mean_tpr = np.mean(tprs, axis = 0)
    mean_auc = auc(mean_fpr, mean_tpr)
    std_auc = np.std(aucs)

    std_tpr = np.std(tprs, axis=0)
    tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
    tprs_lower = np.maximum(mean_tpr - std_tpr, 0)

    plt.figure(figsize=figsize)
    # Plot each fold
    for i in range(cvfold):
        plt.plot(fprlist[i], 
                tprlist[i], 
                alpha=0.3, 
                linewidth=2,
                label = "ROC fold %d (AUC = %.2f)"%(i, aucs[i]))
    # Plot the chance
    plt.plot([0, 1], [0, 1], linestyle='--', linewidth=2, color='r', alpha=.8)
    # Plot the mean one
    plt.plot(mean_fpr, 
            mean_tpr, 
            color='b', 
            linewidth = 2,
            label=r'Mean ROC (AUC = %0.2f $\pm$ %0.2f)' % (mean_auc, std_auc), alpha=.8)
    # Plot the variances
    plt.fill_between(mean_fpr, 
                    tprs_lower, 
                    tprs_upper, 
                    color='grey', 
                    alpha=.2, label=r'$\pm$ 1 std. dev.')

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    # plt.title('ROC for each fold')
    plt.legend(ncol=2, loc='lower right')
    plt.tight_layout()

    return plt



if __name__ == "__main__":
    cv = 10
    # seed = 42435 42435 makes auc 0.84
    seed = 42435

    # Load Data
    datafile = "../Data/L_H-1_1.csv"
    # Get Training Data with Label
    X, y = LoadTrainData(datafile)

    X_train, _, y_train, _ = train_test_split(X, y, random_state=2)

    X_trainList, y_trainList, X_testList, y_testList = GetTestFoldResult(X_train, y_train, cv, seed)

    estimator = XGBClassifier(
        colsample_bytree = 0.97,
        gamma= 0.04,
        learning_rate= 0.197,
        max_depth= 10,
        n_estimators= 11,
        subsample= 0.96,
        random_state=42)
    # estimator = SVC(
    #     kernel='rbf', 
    #     C=500,
    #     gamma=0.5,
    #     probability=True
    # )

    fprlist, tprlist, tprs, aucs, pres, yreal, yprob, prscores, prelist, reclist, reports = GetCVScore(X_trainList, y_trainList, X_testList, y_testList, estimator, cv)

    PlotROC(fprlist, tprlist, tprs, aucs, cv, figsize=(6.6, 4))
    # plt.savefig("ControlResults/10FoldCVROC_XGB.png",bbox_inches = "tight")
    # plt.savefig("ControlResults/10FoldCVROC_XGB.pdf",bbox_inches = "tight")

    # PlotPRC(pres, yreal, yprob, prscores, prelist, reclist, cv)
#     plt.savefig("10FoldCV_Resample_PRC.png",bbox_inches = "tight")
#     plt.savefig("10FoldCV_Resample_PRC.eps",bbox_inches = "tight")
#     plt.show()
    for i in range(10):
        print (reports[i])

    plt.show()
    


