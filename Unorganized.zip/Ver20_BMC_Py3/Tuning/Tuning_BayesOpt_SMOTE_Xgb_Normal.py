# %%
import numpy as np
import pandas as pd
from bayes_opt import BayesianOptimization
from xgboost.sklearn import XGBClassifier
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold, train_test_split
import warnings

# Load the data for training
def LoadTrainData(datapath):
    data = pd.read_csv(datapath)

    TrainingSet = np.zeros((data.shape[0],9))
    TrainingSet[:,0] = np.asarray(data['MassDev'])
    TrainingSet[:,1] = np.asarray(data['PPR'])
    TrainingSet[:,2] = np.asarray(data['S/N'])
    TrainingSet[:,3] = np.asarray(data['IsoDev1_Light'])
    TrainingSet[:,4] = np.asarray(data['IsoDev2_Light'])
    TrainingSet[:,5] = np.asarray(data['IsoDev3_Light'])
    TrainingSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    TrainingSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    TrainingSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 

    TrainingLabel = np.asarray(data['FinalLabel'])

    return TrainingSet, TrainingLabel

# Get the k-fold data for cross validation manually
def GetFold(data, targets, cv, seed):
    Stratified_folder = StratifiedKFold(n_splits=cv, random_state=seed)
    FolderRes = Stratified_folder.split(data, targets)

    data = StandardScaler().fit_transform(data)

    # Get each k-fold results
    FoldXtrain = []
    Foldytrain = []
    FoldXtest = []
    Foldytest = []

    for train_index, test_index in FolderRes:
        # Original result for each fold
        X_train = data[train_index, :]
        y_train = targets[train_index]

        X_test = data[test_index, :]
        y_test = targets[test_index]
        
        FoldXtrain.append(X_train)
        Foldytrain.append(y_train)

        FoldXtest.append(X_test)
        Foldytest.append(y_test)

    return FoldXtrain, Foldytrain, FoldXtest, Foldytest

# Define a score function for smote xgb evaluation by cross validation
def GetCVScore(estimator, data, targets, cv, seed):
    X_trainList, y_trainList, X_testList, y_testList = GetFold(data, targets, cv, seed)
    aucs = []

    for i in range(cv):
        X_train = X_trainList[i]
        y_train = y_trainList[i]
        X_test = X_testList[i]
        y_test = y_testList[i]

        X_res, y_res = SMOTE(random_state=seed).fit_resample(X_train, y_train)
        clf = estimator
        clf.fit(X_res, y_res)
        
        y_pred_prob = clf.predict_proba(X_test)[:, 1]
       
        # ROC 
        fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)

    return np.mean(aucs)

# Prepare xgb for bayes opt
def xgb_cv(n_estimator, max_depth, learning_rate, col_bytree, gamma, subsample, seed, data, targets):
    estimator = XGBClassifier(n_estimators=n_estimator, 
                    max_depth=max_depth, 
                    learning_rate=learning_rate, 
                    colsample_bytree=col_bytree, 
                    gamma=gamma, 
                    subsample=subsample,
                    random_state=seed)
    cval = GetCVScore(estimator, data, targets, cv=10, seed=seed)
    return cval

# Optimizing by bayesian
def optimize_xgb(data, targets, seed):
    """Apply Bayesian Optimization to Xgb parameters."""
    def xgb_crossval(n_estimators, max_depth, learning_rate, colsample_bytree, gamma, subsample):
        return xgb_cv(n_estimator = int(n_estimators), 
                    max_depth = int(max_depth), 
                    learning_rate = learning_rate, 
                    col_bytree = colsample_bytree,
                    gamma = gamma, 
                    subsample = subsample,
                    seed=seed,
                    data=data, 
                    targets=targets)

    optimizer = BayesianOptimization(
        f=xgb_crossval,
        pbounds={'n_estimators': (10, 2000),
            'max_depth': (3, 10),
            'learning_rate': (0.01, 0.3),
            'colsample_bytree': (0.7, 1),
            'gamma': (0, 0.05),
            'subsample': (0.7, 1)},
        random_state=seed)
    
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore')
        optimizer.maximize(n_iter=30, acq='ei')

    return optimizer

if __name__ == "__main__":
    # Load Data
    # X = pd.read_csv("ProcessedData/TrainingSet.csv")
    # y = np.loadtxt("ProcessedData/TrainingLabel.txt", dtype = int)

    datafile = "../Data/L_H-1_1.csv"
    # Get Training Data with Label
    Data, targets = LoadTrainData(datafile)
    X_train, X_test, y_train, y_test = train_test_split(Data, targets, test_size=0.25, random_state=2)

    # np.savez("testset.npz", X_test='TestSet', y_test='TestLabel')

    OptRes = optimize_xgb(X_train, y_train, seed=42)
    print("Final result:", OptRes.max)

    history_df = pd.DataFrame(OptRes.res)
    history_df.to_csv('TuningResult/10fold-SMOTE-XGB-42.csv')


