import pandas as pd
import numpy as np

def LoadSIDData(data):
    data = pd.read_csv(data)
    AsapRatio = np.asarray(data['asap mean'])
    
    DataSet = np.zeros((data.shape[0],13))
    DataSet[:,0] = np.asarray(data['MassDev'])
    DataSet[:,1] = np.asarray(data['PPR'])
    DataSet[:,2] = np.asarray(data['S/N'])
    DataSet[:,3] = np.asarray(data['IsoDev1_Light'])
    DataSet[:,4] = np.asarray(data['IsoDev2_Light'])
    DataSet[:,5] = np.asarray(data['IsoDev3_Light'])
    DataSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    DataSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    DataSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 
    DataSet[:,9] = np.asarray(data['SIDsum'])  
    DataSet[:,10] = np.asarray(data['SID0']) 
    DataSet[:,11] = np.asarray(data['SID1']) 
    DataSet[:,12] = np.asarray(data['SID2']) 

    return AsapRatio, DataSet


def LoadNormalData(data):
    data = pd.read_csv(data)
    AsapRatio = np.asarray(data['asap mean'])
    
    DataSet = np.zeros((data.shape[0],9))
    DataSet[:,0] = np.asarray(data['MassDev'])
    DataSet[:,1] = np.asarray(data['PPR'])
    DataSet[:,2] = np.asarray(data['S/N'])
    DataSet[:,3] = np.asarray(data['IsoDev1_Light'])
    DataSet[:,4] = np.asarray(data['IsoDev2_Light'])
    DataSet[:,5] = np.asarray(data['IsoDev3_Light'])
    DataSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    DataSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    DataSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 
    
    return AsapRatio, DataSet