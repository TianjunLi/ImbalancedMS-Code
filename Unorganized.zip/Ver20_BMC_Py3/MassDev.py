# %%
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import gridspec as GS
from scipy import stats as ss
from sklearn import preprocessing

data = "../Data/L_H-1_1.csv"

Data = pd.read_csv(data)

MassDev = Data['MassDev']

MassDev = np.asarray(MassDev)

NormalizedMass = preprocessing.StandardScaler().fit_transform(MassDev.reshape(-1,1))


NormalizedMass2 = NormalizedMass.reshape(1,-1)[0]
# %%

print (np.min(NormalizedMass2))
print (np.median(NormalizedMass2))
Na = NormalizedMass2[NormalizedMass2<1]
print (np.mean(Na))
print (np.median(Na))
print (ss.mode(Na)[0][0])

# %%
Mass_DM = ss.gaussian_kde(NormalizedMass2)

_, bins = np.histogram(NormalizedMass2, bins=180, density=True)

# plt.plot(bins, Mass_DM(bins))

# Making Density more beautiful
DensityValues = Mass_DM(bins).tolist()
AddValue = (DensityValues[0]+DensityValues[1])/2

NewValues = np.zeros(len(DensityValues)+2)
NewValues[1] = DensityValues[0]
NewValues[2] = AddValue
NewValues[3:] = DensityValues[1:]


NewBins = np.zeros(len(bins)+2)
NewBins[0] = bins[0]
NewBins[1] = (bins[0]+bins[1])/2
NewBins[2] = bins[1]
NewBins[3] = (bins[1]+bins[2])/2
NewBins[4:] = bins[2:]


from matplotlib import gridspec as gridspec
from matplotlib.font_manager import FontProperties
font = FontProperties()
font.set_size(14)
font.set_weight('bold')
# Plotting the mass deviation value versus the corresponding scan
fig = plt.figure(figsize=(7, 5))
gs = gridspec.GridSpec(2,2)

ax1 = fig.add_subplot(gs[0, :])
# plt.title("Distribution of Mass Deviation, Standardized", fontsize=14, fontname="serif")
ax1.plot(NormalizedMass,"o", ms = 8, mec=(0,0,0,0.35), mew=".8", color = "orange")
ax1.set_xlabel("Scan number", fontsize=12)
ax1.set_ylabel("Standardized\nMass Deviation", fontsize=12)
ax1.text(-180, 7.1, 'a', fontproperties=font)

# plt.savefig("Results/MassDev.eps", bbox_inches="tight")


ax2 = fig.add_subplot(gs[1, 0])
# plt.title("Histogram for the Standardized Distribution", fontsize=14, fontname="serif")
ax2.hist(NormalizedMass2, bins=180)
ax2.set_xlabel("Value", fontsize=12)
ax2.set_ylabel("Frequency", fontsize=12)
ax2.text(-1.3, 1050, 'b', fontproperties=font)

# plt.savefig("Results/MassDev-Hist.eps", bbox_inches="tight")

ax3 = fig.add_subplot(gs[1,1])
# plt.title("Density Map for the Standardized Distribution", fontsize=14, fontname="serif")
ax3.plot(NewBins, NewValues)
ax3.plot(0.5, 0, "|", color='red', markersize=20, mew=3)
ax3.set_xlabel("Value", fontsize=12)
ax3.set_ylabel("Probability density", fontsize=12)
ax3.text(-1.3, 1.75, 'c', fontproperties=font)
plt.tight_layout()
# plt.savefig("Results/MassDev_Density.eps", bbox_inches="tight")
plt.subplots_adjust(hspace=0.4)
plt.savefig("MassDev.eps", dpi=300, bbox_inches='tight')
plt.show()

# Plotting the density map of mass deviation

