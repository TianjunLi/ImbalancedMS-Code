import numpy as np
import pandas as pd
from xgboost.sklearn import XGBClassifier
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.externals import joblib

# Load the data for training
def LoadTrainData(datapath):
    data = pd.read_csv(datapath)

    TrainingSet = np.zeros((data.shape[0],13))
    TrainingSet[:,0] = np.asarray(data['MassDev'])
    TrainingSet[:,1] = np.asarray(data['PPR'])
    TrainingSet[:,2] = np.asarray(data['S/N'])
    TrainingSet[:,3] = np.asarray(data['IsoDev1_Light'])
    TrainingSet[:,4] = np.asarray(data['IsoDev2_Light'])
    TrainingSet[:,5] = np.asarray(data['IsoDev3_Light'])
    TrainingSet[:,6] = np.asarray(data['IsoDev1_Heavy'])
    TrainingSet[:,7] = np.asarray(data['IsoDev2_Heavy'])
    TrainingSet[:,8] = np.asarray(data['IsoDev3_Heavy']) 
    TrainingSet[:,9] = np.asarray(data['SIP'])  
    TrainingSet[:,10] = np.asarray(data['Scan0IP']) 
    TrainingSet[:,11] = np.asarray(data['Scan1IP']) 
    TrainingSet[:,12] = np.asarray(data['Scan2IP']) 

    TrainingLabel = np.asarray(data['FinalLabel'])

    return TrainingSet, TrainingLabel


if __name__ == "__main__":

    datafile = "../Data/L_H-1_1.csv"
    seed = 42

    # Get Training Data with Label
    Data, targets = LoadTrainData(datafile)

    Data = StandardScaler().fit_transform(Data)

    X_train, X_test, y_train, y_test = train_test_split(Data, targets, test_size=0.25, random_state=2)


    X_res, y_res = SMOTE(random_state=seed).fit_resample(X_train, y_train)

    clf = XGBClassifier(
        colsample_bytree = 0.77,
        gamma= 0.05,
        learning_rate= 0.01,
        max_depth= 10,
        n_estimators= 154,
        subsample= 1,
        random_state=seed)

    Estimator = clf.fit(X_res, y_res)

    # joblib.dump(Estimator, "S-XGB.pkl")

    y_pred = Estimator.predict(X_test)
    from sklearn.metrics import classification_report
    print (classification_report(y_test, y_pred))