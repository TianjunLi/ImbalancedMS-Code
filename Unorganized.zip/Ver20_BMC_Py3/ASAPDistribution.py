import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import gridspec as gs

data = "../Data/L_H-1_1.csv"

Data = pd.read_csv(data)

AsapRatio1 = Data['asap mean'].tolist()

AsapRatio = np.log(AsapRatio1)

Mean = np.mean(AsapRatio)
Std = np.std(AsapRatio)
LeftBoundary = Mean - 3*Std
RightBoundary = Mean + 3*Std

from matplotlib import gridspec as gridspec
from matplotlib.font_manager import FontProperties
font = FontProperties()
font.set_size(14)
font.set_weight('bold')

fig = plt.figure(figsize=(7, 5))
gs = gridspec.GridSpec(2,3)

ax1 = fig.add_subplot(gs[0,:])
ax1.plot(AsapRatio1,"o", ms = 8, mec="black", mew=".8")
ax1.text(-160, 49, 'a', fontproperties=font)
ax1.set_xlabel("Scan Number", fontsize=12)
ax1.set_ylabel("ASAPRatio", fontsize=12)

ax2 = fig.add_subplot(gs[1,:2])
ax2.plot(AsapRatio,"o", ms = 8, mec="black", mew=".8")
# ax2.axhline(y=LeftBoundary, color='red', linestyle=':', lw=2)
# ax2.axhline(y=RightBoundary, color='red', linestyle=':', lw=2)
ax2.text(-200, 4.5, 'b', fontproperties=font)
ax2.set_xlabel("Scan Number", fontsize=12)
ax2.set_ylabel("log(ASAPRatio)", fontsize=12)

# plt.title("Histogram of Log(ASAPRatio)", fontsize=14, fontname="serif")
ax3 = fig.add_subplot(gs[1,-1])
ax3.hist(AsapRatio,bins=100, density=True)
ax3.axvline(x=LeftBoundary, color='red', linestyle=':', lw=2)
ax3.axvline(x=RightBoundary, color='red', linestyle=':', lw=2)
ax3.set_xlabel("Value", fontsize=12)
ax3.set_ylabel("Density frequency", fontsize=12)
ax3.text(-5, 3.25, 'c', fontproperties=font)
# plt.xlabel("   ", fontsize=14, fontname="serif")
plt.tight_layout()
plt.savefig("Asap.eps", dpi=300, bbox_inches="tight")




# plt.savefig("Results/Asap.eps", bbox_inches="tight")
plt.show()