# %%
from collections import defaultdict

import numpy as np
import pandas as pd
from sklearn.externals import joblib
from sklearn.preprocessing import StandardScaler

from Func_LoadData import LoadNormalData, LoadSIDData
from Func_LoadModel import LoadModel


def SortDesc(vector):
    """
    vector: The needed sorted input
    Returns:
            SortIndex: The index with sorted results
            SortValue: The sorted results, desc
    """
    SortResult = sorted(enumerate(vector), key=lambda x:x[1], reverse=True)
    length = len(SortResult)
    #Get the index and the value
    SortIndex = []
    SortValue = []
    for i in range(length):
        SortIndex.append(SortResult[i][0])
        SortValue.append(SortResult[i][1])
        
    return SortIndex, SortValue

def GetProteinInfo(Data):
    # Get all the protein names
    AllProteinNames = Data['protein'].tolist()
    # Get the same protein names and its corresponding index
    ProteinDict = defaultdict(list)
    for k,va in [(v,i) for i,v in enumerate(AllProteinNames)]:
        ProteinDict[k].append(va)
    # Protein Name
    ProteinName = list(ProteinDict.keys())
    # Get each unique protein number
    ProteinAmount = []
    # Get each unique protein corresponding index
    ProteinIndex = []
    for value in list(ProteinDict.values()):
        ProteinAmount.append(len(value))
        ProteinIndex.append(value)

    return ProteinName, ProteinAmount, ProteinIndex

def GetProtein(Data, ProteinIndex, index):
    NeedIndex = ProteinIndex[index]
    Protein = Data.loc[NeedIndex]
    Ratio = np.log2(np.asarray(Protein['asap mean']))
    return Protein, Ratio

def GetAssess(Protein):
    Assessed = Protein[Protein['XGBPred']==1]
    Ratios = np.log2(np.asarray(Assessed['asap mean']))
    return Ratios, len(Ratios), np.mean(Ratios), np.std(Ratios)

def GetPredRes(datapath):
    xgbclf = LoadModel('smote-sidxgb')
    _, SIDData = LoadSIDData(datapath)
    SIDData = StandardScaler().fit_transform(SIDData)
    XGBPred = xgbclf.predict(SIDData)
    return XGBPred

def PlotDetails(datapath, ProteinOrder):
    XGBPred = GetPredRes(datapath)
    Data = pd.read_csv(datapath)
    Data = Data.assign(XGBPred = XGBPred)
    ProteinName, ProteinAmount, ProteinIndex = GetProteinInfo(Data)
    SI, SV = SortDesc(ProteinAmount)
    ProteinData, Ori_Asap = GetProtein(Data, ProteinIndex, SI[ProteinOrder])
    Assed_Ratios, Assed_Len, Assed_Mean, Assed_Std = GetAssess(ProteinData)

    AssDict = {}
    AssDict['Protein'] = [ProteinName[SI[ProteinOrder]]]
    AssDict['Ori_Number'] = [len(Ori_Asap)]
    AssDict['Assessed Num'] = [Assed_Len]

    AssDict['Ori_Mean'] = [np.mean(Ori_Asap)]
    AssDict['Ori_Std'] = [np.std(Ori_Asap)]

    AssDict['Assessed Mean'] = [Assed_Mean]
    AssDict['Assessed Std'] = [Assed_Std]

    df = pd.DataFrame(AssDict, index=None, columns = ['Protein', 'Ori_Number', 'Assessed Num', 'Assessed Num', 'Ori_Mean', 'Ori_Std', 'Assessed Mean', 'Assessed Std'])

    return ProteinName[SI[ProteinOrder]], Ori_Asap, Assed_Ratios, df




# %%
if __name__ == "__main__":

    datapath1 = '../Data/L_H-1_1.csv'
    Name1_1, Ori_Ratio1_1, Ass_Ratio1_1, df1_1 = PlotDetails(datapath1, 0)
    Name1_2, Ori_Ratio1_2, Ass_Ratio1_2, df1_2 = PlotDetails(datapath1, 4)

    datapath2 = '../Data/L_H-1-5_1.csv'
    Name2_1, Ori_Ratio2_1, Ass_Ratio2_1, df2_1 = PlotDetails(datapath2, 3)
    Name2_2, Ori_Ratio2_2, Ass_Ratio2_2, df2_2 = PlotDetails(datapath2, 5)

    frames = [df1_1, df1_2, df2_1, df2_2]
    TotalDF = pd.concat(frames, keys=['{} in 1:1'.format(Name1_1), '{} in 1:1'.format(Name1_2), '{} in 1.5:1'.format(Name2_1), '{} in 1.5:1'.format(Name2_2)])

    TotalDF.to_csv("ControlResults/Protein.csv", index=None)

    from matplotlib import pyplot as plt
    from matplotlib.lines import Line2D
    LegendItem = [Line2D([0], [0], color='orange', lw=3, label="Median"), Line2D([0], [0], color='w', markerfacecolor='g', marker='o', label='Mean')]

    fig = plt.figure(figsize=(9, 5))

    ax1 = fig.add_subplot(2,2,1)
    ax1.set_title("{} in Ratio 1:1 Sample".format(Name1_1))
    ax1.boxplot([Ori_Ratio1_1, Ass_Ratio1_1], medianprops={"linewidth":3},showfliers=False, notch=True, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'g'}, labels=["Without Assessment", "SMOTE XGB Assessed"], widths=(0.4,0.4))
    ax1.set_ylabel(r'$\log_2$(ASAPRatio)')
    ax1.legend(handles = LegendItem, loc='lower center')

    ax2 = fig.add_subplot(2,2,2)
    ax2.set_title("{} in Ratio 1:1 Sample".format(Name1_2))
    ax2.boxplot([Ori_Ratio1_2, Ass_Ratio1_2], medianprops={"linewidth":3},showfliers=False, notch=True, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'g'}, labels=["Without Assessment", "SMOTE XGB Assessed"],widths=(0.4,0.4))
    ax2.set_ylabel(r'$\log_2$(ASAPRatio)')
    ax2.yaxis.set_label_coords(-0.1,0.5)
    ax2.legend(handles = LegendItem, loc='lower center')

    ax3 = fig.add_subplot(2,2,3)
    ax3.set_title("{} in Ratio 1.5:1 Sample".format(Name2_1))
    ax3.boxplot([Ori_Ratio2_1, Ass_Ratio2_2], medianprops={"linewidth":3},showfliers=False, notch=True, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'g'}, labels=["Without Assessment", "SMOTE XGB Assessed"], widths=(0.4,0.4))
    ax3.set_ylabel(r'$\log_2$(ASAPRatio)')
    ax3.legend(handles = LegendItem, loc='lower center')

    ax4 = fig.add_subplot(2,2,4)
    ax4.set_title("{} in Ratio 1.5:1 Sample".format(Name2_2))
    ax4.boxplot([Ori_Ratio2_2, Ass_Ratio2_2], medianprops={"linewidth":3},showfliers=False, notch=True, showmeans=True, meanprops = {'marker':'o', 'markerfacecolor':'g'}, labels=["Without Assessment", "SMOTE XGB Assessed"], widths=(0.4,0.4))
    ax4.set_ylabel(r'$\log_2$(ASAPRatio)')
    ax4.legend(handles = LegendItem, loc='lower center')

    plt.tight_layout()
    plt.subplots_adjust(wspace=0.2, hspace=0.3)
    plt.savefig("ControlResults/Protein.eps", dpi=300, bbox_inches='tight')
    plt.savefig("ControlResults/Protein.png", dpi=300, bbox_inches='tight')

    plt.show()